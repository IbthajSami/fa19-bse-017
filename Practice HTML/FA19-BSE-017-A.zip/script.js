let btnGet = document.querySelector('button');
let input = document.querySelector('input');
let result = document.querySelector('h1');

btnGet.addEventListener('click',() =>{
    result.innerText = input.value.length;
});


// let users = ['Peter', 'Marks', 'John', 'James', 'Mary', 'James', 'Mary', 'James', 'Mary'];

// function addUsers(usernames){
//     let template = usernames.map(user => `<li>${user}</li>`).join('\n');
//     document.querySelector('ul').innerHTML = template;
// }

// addUsers(users);

// let btGet = document.querySelector('button');

// btGet.addEventListener('click', () => {    
//     let usernames = users.filter((user, index) => users.indexOf(user) != index);
//     let set = new Set(usernames);
//     usernames = Array.from(set);
//     addUsers(usernames);
// });